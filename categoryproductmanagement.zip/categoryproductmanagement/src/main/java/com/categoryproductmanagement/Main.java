package com.categoryproductmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.categoryproductmanagement.entities")
@EnableJpaRepositories(basePackages = "com.categoryproductmanagement.repositories")
public class Main 
{
    public static void main(String[] args) 
    {
        SpringApplication.run(Main.class, args);
    }
}


