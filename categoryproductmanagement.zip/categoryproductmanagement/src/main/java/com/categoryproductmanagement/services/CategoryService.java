package com.categoryproductmanagement.services;



//import com.example.demo.entity.Category;
//import com.example.demo.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.categoryproductmanagement.entities.Category;
import com.categoryproductmanagement.repositories.CategoryRepository;

import java.util.Optional;

@Service
public class CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    public Page<Category> getAllCategories(int page) {
        Pageable pageable = PageRequest.of(page, 10);
        return categoryRepository.findAll(pageable);
    }

    public Optional<Category> getCategoryById(Long id) {
        return categoryRepository.findById(id);
    }

    public Category createCategory(Category category) {
        return categoryRepository.save(category);
    }

    public Category updateCategory(Long id, Category categoryDetails) {
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        category.setName(categoryDetails.getName());
        return categoryRepository.save(category);
    }

    public void deleteCategory(Long id) {
        categoryRepository.deleteById(id);
    }

	public Category saveCategory(Category category) {
		// TODO Auto-generated method stub
		categoryRepository.save(category);
		return null;
	}
}




/*
import org.springframework.data.domain.Page;

import com.categoryproductmanagement.entities.Category;

public class CategoryService {

	public Page<Category> getAllCategories(int page) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getCategoryById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public Category createCategory(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	public Category updateCategory(Long id, Category categoryDetails) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteCategory(Long id) {
		// TODO Auto-generated method stub
		
	}


}
*/