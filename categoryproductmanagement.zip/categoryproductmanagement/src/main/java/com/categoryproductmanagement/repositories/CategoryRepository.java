package com.categoryproductmanagement.repositories;


import com.categoryproductmanagement.entities.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {

	
}
/*

//import com.example.demo.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

import com.categoryproductmanagement.entities.Category;

public interface CategoryRepository extends JpaRepository<Category, Long> 
{
}
*/






/*
import java.util.Locale.Category;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {

	Category save(Category category);
}*/