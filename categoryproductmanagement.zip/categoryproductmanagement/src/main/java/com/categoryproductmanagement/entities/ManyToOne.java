package com.categoryproductmanagement.entities;

public @interface ManyToOne {

}
