package com.categoryproductmanagement.entities;

public @interface JoinColumn {

	

	String name();

	boolean nullable();

}
