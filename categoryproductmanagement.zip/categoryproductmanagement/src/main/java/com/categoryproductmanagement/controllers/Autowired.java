package com.categoryproductmanagement.controllers;

public @interface Autowired {

}
