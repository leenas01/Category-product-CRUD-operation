package com.categoryproductmanagement.controllers;


//import com.example.demo.entity.Category;
//import com.example.demo.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.categoryproductmanagement.entities.Category;
import com.categoryproductmanagement.services.CategoryService;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping
    public ResponseEntity<Page<Category>> getAllCategories(@RequestParam(defaultValue = "0") int page) {
        Page<Category> categories = categoryService.getAllCategories(page);
        return ResponseEntity.ok(categories);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long id) {
        Category category = ( categoryService.getCategoryById(id))
                .orElseThrow(() -> new RuntimeException("Category not found"));
        return ResponseEntity.ok(category);
    }

  /*  @PostMapping
    public ResponseEntity<Category> createCategory(@RequestBody Category category) {
        Category createdCategory = categoryService.createCategory(category);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdCategory);
    }
*/
    
    @PostMapping
    public ResponseEntity<?> createCategory(@Validated @RequestBody Category category, BindingResult result) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getAllErrors());
        }
        Category savedCategory = categoryService.saveCategory(category);
        return ResponseEntity.ok(savedCategory);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Category> updateCategory(@PathVariable Long id, @RequestBody Category categoryDetails) {
        Category updatedCategory = categoryService.updateCategory(id, categoryDetails);
        return ResponseEntity.ok(updatedCategory);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Long id) {
        categoryService.deleteCategory(id);
        return ResponseEntity.noContent().build();
    }
}







/*
import java.util.Locale.Category;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.categoryproductmanagement.repositories.CategoryRepository;

@RestController
@RequestMapping("/api/categories")
public class CategoryController 
{
    @Autowired
    private CategoryRepository categoryRepository;
    
    @GetMapping
    public Page<Category> getAllCategories(@RequestParam(defaultValue = "0") int page) 
    {
        return categoryRepository.findAll(PageRequest.of(page, 10));
    }
    
    @PostMapping
    public Category createCategory(@RequestBody Category category) 
    {
        return categoryRepository.save(category);
    }
    
    @GetMapping("/{id}")
    public Category getCategoryById(@PathVariable Long id) 
    {
        return categoryRepository.findById(id).orElseThrow();
    }
    
    @PutMapping("/{id}")
    public Category updateCategory(@PathVariable Long id, @RequestBody Category category) 
    {
        Category existingCategory = categoryRepository.findById(id).orElseThrow();
		return existingCategory;
    }
}
    */   